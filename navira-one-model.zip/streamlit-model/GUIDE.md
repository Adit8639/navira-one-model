# Navira One Repair Model: how to run it, put it online and present it

## What is in this folder
- `app.py`: the whole app.
- `requirements.txt`: the libraries Streamlit Cloud installs.
- `.streamlit/config.toml`: forces the white "paper" theme. The folder name starts with a dot, so some computers hide it. Upload it anyway.

The app has six screens:

| Screen | When you use it |
|---|---|
| **Overview** | Opening view: 4 large numbers and the plan in four lines. |
| **1 · Refusal switch** | LIVE DEMO 1. One toggle, before vs after. |
| **2 · Stress test** | LIVE DEMO 2. "All at worst" button, live check against the reserve. |
| **3 · District board** | Q&A only: "How do you know a district is failing?" |
| **4 · Money** | Q&A only: "Where does the money go? Who pays after month 24?" |
| **5 · Rekha's case** | Q&A only: "What does a citizen actually see?" |

Every number matches the deck. Two numbers differ by ₹1 because the app does not round them:
- **Worst case:** the app shows +₹881 Cr and ₹31 Cr short. The deck says +880 and 30 short.
- **Benefit bar:** the app shows +169. The deck says +170.

If asked, say "the deck rounds to the nearest 10".

---

## Part A: Put it online (about 10 minutes, one time only)

### Step 1: Make a GitHub repository
1. Go to github.com and sign in, or create a free account.
2. Click the **+** at the top right, then **New repository**.
3. Name it `navira-one-model`, set it to **Public**, and click **Create repository**.

### Step 2: Put the files in the repository
You have two ways to do this.

**Option 1: send me the name and I push the files for you.**
1. Make sure your GitHub is connected to Claude at https://claude.ai/connect-github.
2. Reply in the thread with "pushed repo: <your-username>/navira-one-model".

**Option 2: upload them yourself.**
1. In the new repository, click **uploading an existing file**.
2. Drag in `app.py` and `requirements.txt`, then click **Commit changes**.
3. Click **Add file**, then **Create new file**.
4. Type the name `.streamlit/config.toml`. The slash creates the folder.
5. Paste in the contents of the config.toml file from this folder, then click **Commit changes**.

### Step 3: Deploy on Streamlit
1. Go to share.streamlit.io and click **Continue with GitHub**.
2. Click **Create app**, then **Deploy a public app from GitHub**.
3. Fill in:
   - Repository: `<your-username>/navira-one-model`
   - Branch: `main`
   - Main file path: `app.py`
4. Optional: set the App URL to something short, such as `navira-one-artha`.
5. Click **Deploy**. The first start takes 2 to 4 minutes.
6. Copy the link and make a QR code from it with any free QR site. Put the QR code on the thank-you slide or on slide 6.

### Before the final
- **Open the link 10 minutes before you present.** A free Streamlit app sleeps after a few days without visitors and takes about 30 seconds to wake up.
- **Keep a backup.** Save screenshots of screens 1 and 2 in case the venue Wi-Fi fails.

## Part B: Run it on your own laptop (optional)
1. Install Python from python.org. Tick "Add Python to PATH" during setup.
2. Open the folder in VS Code, then open **Terminal**, then **New Terminal**.
3. Run `pip install -r requirements.txt`
4. Run `streamlit run app.py`. It opens in your browser at http://localhost:8501.

---

## Part C: Live demo script (about 75 seconds, right after slide 6)

**Before you start:** open the app in a browser tab and click **Demo 1** in the left bar. The toggle should be OFF.

**Demo 1, about 30 seconds.**
> "This is a working model of our plan, built on the same numbers as the deck. Right now it runs the old setup: the model refuses on its own, and about one refusal in three is wrong. That is 3.4 lakh people over two years. Now we switch on our rule, only a named officer can refuse."

*Flip the toggle.*

> "It drops to about 17,000. The cost is about 90 full-time officers, which we accept."

**Demo 2, about 45 seconds.**

*Click "Next: Stress test".*

> "Now, what if our numbers are wrong? These are the five inputs we are least sure about. Each one alone stays well inside the ₹850 Cr reserve."

*Point at the tornado chart, then click **All at worst**.*

> "If all five go wrong at once, we need ₹881 Cr, which is ₹31 Cr over the reserve. That gap comes out of year-2 reform, about 4% of it, and every other part of the plan keeps going."

*Go back to the deck.*

## Part D: Which screen answers which judge question

| Judge asks | Open | Say |
|---|---|---|
| "Why not just fix the model?" | 1 | Even a 95% fix still leaves the model able to refuse alone. We take the "no" away, not just reduce it. |
| "Won't refusals get slow?" | 1 | Yes. About 90 officers, and we say so on day one. Move the minutes slider to show the cost. |
| "How do you know a district is failing?" | 3 | Raise the error slider to 5%. Red districts appear, each gets reserve desks, and the desk count stays under 5,000. |
| "What if your 2% / 5% lines are wrong?" | 3 | They are starting lines, reset after six months of data. |
| "Is ₹850 Cr enough?" | 2, open "10,000 random futures" | It covered every one of 10,000 random futures. A bad 1-in-20 future needs about ₹300 Cr. |
| "Who pays after month 24?" | 4 | Move the duplicates slider. Savings cover about 60%; ₹140 Cr is left, about ₹29 per citizen. |
| "Why not sell ID checks?" | 4, the note under "Value per person" | A state that just leaked records should not sell lookups on them. |
| "What does a citizen see?" | 5 | Move the case slider from Day 0 to Month 3. Lost pension is ₹6,000 before and ₹0 after. |

The district names (D01 North and so on) are placeholders. The case gives no district list, and we assume about 30 districts.
